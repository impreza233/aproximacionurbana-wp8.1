using AproximacionUrbana;

namespace AproximacionUrbana.Views
{
    public sealed partial class NoticiasDeUrbanismoListPage : PageBase
    {
    }
}
