using Windows.UI.Xaml.Navigation;
using AppStudio.Common;
using AppStudio.DataProviders.Rss;
using AproximacionUrbana;
using AproximacionUrbana.Sections;
using AproximacionUrbana.ViewModels;

namespace AproximacionUrbana.Views
{
    public sealed partial class NoticiasDeUrbanismoListPage : PageBase
    {
        public ListViewModel<RssDataConfig, RssSchema> ViewModel { get; set; }

        public NoticiasDeUrbanismoListPage()
        {
            this.ViewModel = new ListViewModel<RssDataConfig, RssSchema>(new NoticiasDeUrbanismoConfig());
            this.InitializeComponent();
        }

        protected async override void LoadState(object navParameter)
        {
            await this.ViewModel.LoadDataAsync();
        }

    }
}
