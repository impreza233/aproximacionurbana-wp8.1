namespace AproximacionUrbana
{
    public sealed partial class MainPage : PageBase
    {
    }
}
