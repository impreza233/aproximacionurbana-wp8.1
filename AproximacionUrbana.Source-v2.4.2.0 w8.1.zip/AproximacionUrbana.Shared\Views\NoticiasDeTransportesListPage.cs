using Windows.UI.Xaml.Navigation;
using AppStudio.Common;
using AppStudio.DataProviders.Rss;
using AproximacionUrbana;
using AproximacionUrbana.Sections;
using AproximacionUrbana.ViewModels;

namespace AproximacionUrbana.Views
{
    public sealed partial class NoticiasDeTransportesListPage : PageBase
    {
        public ListViewModel<RssDataConfig, RssSchema> ViewModel { get; set; }

        public NoticiasDeTransportesListPage()
        {
            this.ViewModel = new ListViewModel<RssDataConfig, RssSchema>(new NoticiasDeTransportesConfig());
            this.InitializeComponent();
        }

        protected async override void LoadState(object navParameter)
        {
            await this.ViewModel.LoadDataAsync();
        }

    }
}
