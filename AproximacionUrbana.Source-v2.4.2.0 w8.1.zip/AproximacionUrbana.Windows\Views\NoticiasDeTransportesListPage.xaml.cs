using AproximacionUrbana;

namespace AproximacionUrbana.Views
{
    public sealed partial class NoticiasDeTransportesListPage : PageBase
    {
    }
}
