using AproximacionUrbana;

namespace AproximacionUrbana.Views
{
    public sealed partial class NoticiasDeTransportesDetailPage : PageBase
    {
    }
}
