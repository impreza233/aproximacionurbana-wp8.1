using AproximacionUrbana;

namespace AproximacionUrbana.Views
{
    public sealed partial class NoticiasDeUrbanismoDetailPage : PageBase
    {
    }
}
