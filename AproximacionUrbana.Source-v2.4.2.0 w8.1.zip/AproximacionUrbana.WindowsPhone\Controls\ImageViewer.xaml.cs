namespace AproximacionUrbana.Controls
{
    public sealed partial class ImageViewer : PageBase
    {
    }
}
